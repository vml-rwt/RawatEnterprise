sap.ui.define(["sap/ui/core/mvc/Controller"],t=>{"use strict";return t.extend("rwt.etp.stockmanagement.controller.StockList",{onInit(){}})});
//# sourceMappingURL=StockList.controller.js.map